const WORKER_URL =
  "https://rishi-ai-api.rishiraj98148.workers.dev";

let currentChat = [];
let voiceReplyEnabled = true;


// ===============================
// ELEMENTS
// ===============================

const chatArea = document.getElementById("chatArea");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const micBtn = document.getElementById("micBtn");

const menuBtn = document.getElementById("menuBtn");
const closeMenuBtn = document.getElementById("closeMenuBtn");
const sideMenu = document.getElementById("sideMenu");
const overlay = document.getElementById("overlay");

const newChatBtn = document.getElementById("newChatBtn");
const sideNewChat = document.getElementById("sideNewChat");

const historyList = document.getElementById("historyList");

const themeBtn = document.getElementById("themeBtn");
const voiceReplyBtn = document.getElementById("voiceReplyBtn");

const loginScreen = document.getElementById("loginScreen");
const app = document.getElementById("app");

const loginName = document.getElementById("loginName");
const loginEmail = document.getElementById("loginEmail");
const loginBtn = document.getElementById("loginBtn");

const logoutBtn = document.getElementById("logoutBtn");
const userName = document.getElementById("userName");
const userEmail = document.getElementById("userEmail");


// ===============================
// LOGIN
// ===============================

function checkLogin() {

  const user = localStorage.getItem("myAIUser");

  if (user) {

    const data = JSON.parse(user);

    showApp(data);

  } else {

    loginScreen.classList.remove("hidden");
    app.classList.add("hidden");

  }
}


function showApp(data) {

  loginScreen.classList.add("hidden");
  app.classList.remove("hidden");

  userName.textContent = data.name;
  userEmail.textContent = data.email;

  loadHistory();

}


loginBtn.addEventListener("click", () => {

  const name = loginName.value.trim();
  const email = loginEmail.value.trim();

  if (!name || !email) {

    alert("Please enter your name and email.");

    return;
  }

  const user = {
    name: name,
    email: email
  };

  localStorage.setItem(
    "myAIUser",
    JSON.stringify(user)
  );

  showApp(user);

});


logoutBtn.addEventListener("click", () => {

  if (!confirm("Do you want to logout?")) {
    return;
  }

  localStorage.removeItem("myAIUser");

  location.reload();

});


// ===============================
// DARK MODE
// ===============================

function loadTheme() {

  const theme =
    localStorage.getItem("myAITheme");

  if (theme === "dark") {

    document.body.classList.add("dark");

    themeBtn.textContent = "☀️";

  } else {

    document.body.classList.remove("dark");

    themeBtn.textContent = "🌙";

  }
}


themeBtn.addEventListener("click", () => {

  document.body.classList.toggle("dark");

  const dark =
    document.body.classList.contains("dark");

  localStorage.setItem(
    "myAITheme",
    dark ? "dark" : "light"
  );

  themeBtn.textContent =
    dark ? "☀️" : "🌙";

});


// ===============================
// AI VOICE REPLY
// ===============================

voiceReplyBtn.addEventListener("click", () => {

  voiceReplyEnabled = !voiceReplyEnabled;

  voiceReplyBtn.textContent =
    voiceReplyEnabled ? "🔊" : "🔇";

});


function speakAI(text) {

  if (!voiceReplyEnabled) return;

  if (!("speechSynthesis" in window)) {

    return;
  }

  window.speechSynthesis.cancel();

  const cleanText =
    text.replace(/[*#`]/g, "");

  const speech =
    new SpeechSynthesisUtterance(cleanText);

  speech.lang = "en-US";
  speech.rate = 0.95;
  speech.pitch = 1;

  window.speechSynthesis.speak(speech);

}


// ===============================
// MARKDOWN FORMATTER
// ===============================

function escapeHTML(text) {

  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

}


function formatAIText(text) {

  let html = escapeHTML(text);

  // Code blocks
  html = html.replace(
    /```([\s\S]*?)```/g,
    '<pre class="code-block"><code>$1</code></pre>'
  );

  // Headings
  html = html.replace(
    /^### (.*)$/gm,
    "<h4>$1</h4>"
  );

  html = html.replace(
    /^## (.*)$/gm,
    "<h3>$1</h3>"
  );

  html = html.replace(
    /^# (.*)$/gm,
    "<h2>$1</h2>"
  );

  // Bold
  html = html.replace(
    /\*\*(.*?)\*\*/g,
    "<strong>$1</strong>"
  );

  // Italic
  html = html.replace(
    /(?<!\*)\*(?!\*)(.*?)\*(?!\*)/g,
    "<em>$1</em>"
  );

  // Numbered list
  html = html.replace(
    /^(\d+)\.\s+(.*)$/gm,
    '<div class="number-item"><span class="number">$1.</span><span>$2</span></div>'
  );

  // Bullet list
  html = html.replace(
    /^[*-]\s+(.*)$/gm,
    '<div class="bullet-item"><span class="bullet">•</span><span>$1</span></div>'
  );

  // Inline code
  html = html.replace(
    /`([^`]+)`/g,
    "<code>$1</code>"
  );

  // New lines
  html = html.replace(
    /\n/g,
    "<br>"
  );

  return html;

}


// ===============================
// ADD MESSAGE
// ===============================

function addMessage(text, type) {

  const welcome =
    document.getElementById("welcome");

  if (welcome) {
    welcome.remove();
  }

  const message =
    document.createElement("div");

  message.className =
    "message " +
    (type === "user"
      ? "user-message"
      : "ai-message");

  const avatar =
    document.createElement("div");

  avatar.className = "avatar";

  avatar.textContent =
    type === "user" ? "👤" : "✦";


  const content =
    document.createElement("div");

  content.className =
    "message-content";


  if (type === "user") {

    content.textContent = text;

  } else {

    content.innerHTML =
      formatAIText(text);

  }


  message.appendChild(avatar);
  message.appendChild(content);

  chatArea.appendChild(message);


  if (type === "ai") {

    const copyBtn =
      document.createElement("button");

    copyBtn.className =
      "copy-btn";

    copyBtn.textContent =
      "📋 Copy";

    copyBtn.onclick = () => {

      navigator.clipboard.writeText(text);

      copyBtn.textContent =
        "✅ Copied";

      setTimeout(() => {

        copyBtn.textContent =
          "📋 Copy";

      }, 1500);

    };

    content.appendChild(
      document.createElement("br")
    );

    content.appendChild(copyBtn);

  }


  chatArea.scrollTop =
    chatArea.scrollHeight;

}


// ===============================
// SEND MESSAGE
// ===============================

async function sendMessage() {

  const message =
    messageInput.value.trim();

  if (!message) return;


  addMessage(message, "user");

  currentChat.push({
    role: "user",
    content: message
  });


  messageInput.value = "";

  messageInput.style.height = "auto";


  const loading =
    document.createElement("div");

  loading.className =
    "message ai-message";

  loading.innerHTML = `
    <div class="avatar">✦</div>
    <div class="message-content">
      Thinking...
    </div>
  `;

  chatArea.appendChild(loading);

  chatArea.scrollTop =
    chatArea.scrollHeight;


  try {

    const response =
      await fetch(WORKER_URL, {

        method: "POST",

        headers: {
          "Content-Type": "application/json"
        },

        body: JSON.stringify({
          message: message
        })

      });


    const data =
      await response.json();


    loading.remove();


    if (!response.ok) {

      throw new Error(
        data.error || "AI request failed"
      );

    }


    const reply =
      data.reply || "No response received.";


    addMessage(reply, "ai");


    currentChat.push({
      role: "assistant",
      content: reply
    });


    saveCurrentChat();

    speakAI(reply);


  } catch (error) {

    loading.remove();

    addMessage(
      "❌ Error: " + error.message,
      "ai"
    );

  }

}


sendBtn.addEventListener(
  "click",
  sendMessage
);


// ===============================
// ENTER TO SEND
// ===============================

messageInput.addEventListener(
  "keydown",
  (event) => {

    if (
      event.key === "Enter" &&
      !event.shiftKey
    ) {

      event.preventDefault();

      sendMessage();

    }

  }
);


// ===============================
// AUTO RESIZE
// ===============================

messageInput.addEventListener(
  "input",
  () => {

    messageInput.style.height =
      "auto";

    messageInput.style.height =
      Math.min(
        messageInput.scrollHeight,
        130
      ) + "px";

  }
);


// ===============================
// VOICE INPUT
// ===============================

const SpeechRecognition =
  window.SpeechRecognition ||
  window.webkitSpeechRecognition;

let recognition = null;


if (SpeechRecognition) {

  recognition =
    new SpeechRecognition();

  recognition.lang = "ne-NP";

  recognition.continuous = false;

  recognition.interimResults = false;


  recognition.onstart = () => {

    micBtn.classList.add(
      "listening"
    );

  };


  recognition.onend = () => {

    micBtn.classList.remove(
      "listening"
    );

  };


  recognition.onresult = (event) => {

    const text =
      event.results[0][0].transcript;

    messageInput.value = text;

    messageInput.dispatchEvent(
      new Event("input")
    );

  };


  recognition.onerror = () => {

    micBtn.classList.remove(
      "listening"
    );

  };


  micBtn.addEventListener(
    "click",
    () => {

      try {

        recognition.start();

      } catch (error) {}

    }
  );

} else {

  micBtn.addEventListener(
    "click",
    () => {

      alert(
        "Voice input is not supported in this browser."
      );

    }
  );

}


// ===============================
// CHAT HISTORY
// ===============================

function saveCurrentChat() {

  if (currentChat.length === 0)
    return;


  const history =
    JSON.parse(
      localStorage.getItem(
        "myAIHistory"
      ) || "[]"
    );


  const firstUserMessage =
    currentChat.find(
      item => item.role === "user"
    );


  if (!firstUserMessage)
    return;


  history.unshift({
    title:
      firstUserMessage.content
        .slice(0, 35),

    messages:
      currentChat,

    date:
      new Date().toLocaleString()
  });


  localStorage.setItem(
    "myAIHistory",
    JSON.stringify(history.slice(0, 20))
  );


  loadHistory();

}


function loadHistory() {

  const history =
    JSON.parse(
      localStorage.getItem(
        "myAIHistory"
      ) || "[]"
    );


  historyList.innerHTML = "";


  history.forEach(
    (chat, index) => {

      const item =
        document.createElement("div");

      item.className =
        "history-item";

      item.textContent =
        chat.title || "New Chat";


      item.onclick = () => {

        loadChat(chat);

        closeMenu();

      };


      historyList.appendChild(item);

    }
  );

}


function loadChat(chat) {

  chatArea.innerHTML = "";

  currentChat = [];


  chat.messages.forEach(
    message => {

      addMessage(
        message.content,
        message.role === "user"
          ? "user"
          : "ai"
      );

      currentChat.push(message);

    }
  );

}


// ===============================
// NEW CHAT
// ===============================

function newChat() {

  if (currentChat.length > 0) {

    saveCurrentChat();

  }

  currentChat = [];

  chatArea.innerHTML = `

    <section class="welcome" id="welcome">

      <div class="big-logo">✦</div>

      <h1>How can I help you?</h1>

      <p>Ask me anything.</p>

    </section>

  `;

}


newChatBtn.addEventListener(
  "click",
  newChat
);

sideNewChat.addEventListener(
  "click",
  () => {

    newChat();

    closeMenu();

  }
);


// ===============================
// SIDE MENU
// ===============================

function openMenu() {

  sideMenu.classList.add("open");

  overlay.classList.add("show");

}


function closeMenu() {

  sideMenu.classList.remove("open");

  overlay.classList.remove("show");

}


menuBtn.addEventListener(
  "click",
  openMenu
);

closeMenuBtn.addEventListener(
  "click",
  closeMenu
);

overlay.addEventListener(
  "click",
  closeMenu
);


// ===============================
// START
// ===============================

loadTheme();

checkLogin();